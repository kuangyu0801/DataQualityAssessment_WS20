# Seminar Template
LaTeX-Template for seminar papers
